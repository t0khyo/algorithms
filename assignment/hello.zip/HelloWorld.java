import edu.princeton.cs.algs4.StdOut;

public class HelloWorld {
    /**
     *  Prints "Hello, World"
     *
     * @param args not used
     */
    public static void main(String[] args) {
        StdOut.println("Hello, World");
    }
}